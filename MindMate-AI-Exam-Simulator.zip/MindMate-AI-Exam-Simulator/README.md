# MindMate AI Exam Simulator

A standalone, responsive HTML/CSS/JavaScript exam practice prototype styled with a premium dark MindMate-inspired interface.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser, or use VS Code Live Server.
3. Choose a subject, difficulty, question count, and duration.
4. Start the exam, answer questions, then submit to see the review report.

## Included
- Built-in practice question bank across Computer Networks, System Software, Python for Data Science, Web Development, Project Management, Mathematics, and General Computer Science.
- Timer, question navigation, answer state, optional instant feedback, explanations, scoring, weak-topic identification, retry flow, and text report export.
- Responsive layout and localStorage-free static run (no account/API needed).

## Honest scope
This ZIP is a functional front-end prototype using a bundled demo question bank. It does **not** connect to Gemma, Ollama, Gemini, or another AI model yet. Adaptive mix chooses questions from the local bank; it is not a live AI-generated exam. Connect a secure backend if you want model-generated questions or free-text answer grading.

## Integrating with MindMate
This folder is intentionally standalone so it can be tested without changing your existing project. For integration, move the page into your React/Vite app as a component and port the styles, or link to this standalone page. Avoid replacing your existing app files wholesale; merge only the new feature. If using a backend, keep provider keys on the server, validate all inputs, and never put secret keys in frontend code.
